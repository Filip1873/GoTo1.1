/**
 * @author fil
 */
$(document).ready(function() {
  $('.btnmoj-blob').click(function() {
    $(this).toggleClass('blob');
  });
});